void hello ();

int
main (int argc, char *argv[])
{
  hello ("World");
  return 0;
}

