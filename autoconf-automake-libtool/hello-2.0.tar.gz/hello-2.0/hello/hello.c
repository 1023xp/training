#include <stdio.h>

void
hello (char *who)
{
  printf ("Hello, %s!\n", who);
}

