typedef int foo;
