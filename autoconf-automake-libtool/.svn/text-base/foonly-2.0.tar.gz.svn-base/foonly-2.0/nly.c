typedef int nly;
